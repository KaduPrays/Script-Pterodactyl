#!/bin/bash

output() {
    echo "- $1"
}

output "Reverter alterações após o lançamento"

sed -i "s/.*GITHUB_SOURCE=.*/GITHUB_SOURCE=\"master\"/" panel_1.sh
sed -i "s/.*SCRIPT_RELEASE=.*/SCRIPT_RELEASE=\"canary\"/" panel_1.sh

sed -i "s/.*GITHUB_SOURCE=.*/GITHUB_SOURCE=\"master\"/" wings_1.sh
sed -i "s/.*SCRIPT_RELEASE=.*/SCRIPT_RELEASE=\"canary\"/" wings_1.sh

output "Confirmar as alterações"

git add .
git commit -S -m "Definir versão para desenvolvimento"
git push

output "Alterações relevantes revertidas"
