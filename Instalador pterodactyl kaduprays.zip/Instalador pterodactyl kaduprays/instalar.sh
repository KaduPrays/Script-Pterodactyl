#!/bin/bash
set -e
# CONFIG DO SCRIPT #
SCRIPT_VERSION="v1.0"
LINHA1="Instalador do Pterodactyl 2021"
AJUDA="Precisa de suporte?"
AJUDA2="Atenção"
CRIADOR="KADUPRAYS"
EMAIL="suporte@kaduprays.com"
LINK="https://kaduprays.com/instalar.sh"
DISCORD="KaduPrays#7519"
LEMBRETE="Script não oficial do pterodactyl.io"
COPYRIGHT="Copyright (C) 2021"
SUPORTE="Precisa de suporte?"
GRUPO_DISCORD="https://discord.gg/prFQRzPRbZ"
# NÃO ALTERAR AS LINHAS DE CIMA #

if [[ $EUID -ne 0 ]]; then
  echo "* Este script deve ser executado com privilégios de root (sudo)." 1>&2
  exit 1
fi

if ! [ -x "$(command -v curl)" ]; then
  echo "* curl é necessário para que este script funcione."
  echo "* instalar usando apt (Debian e derivados) ou yum/dnf (CentOS)"
  exit 1
fi

output() {
  echo -e "* ${1}"
}

error() {
  COLOR_RED='\033[0;31m'
  COLOR_NC='\033[0m'

  echo ""
  echo -e "* ${COLOR_RED}ERRO${COLOR_NC} > $1"
  echo ""
}

done=false

output "$LINHA1 @ $SCRIPT_VERSION"
output
output "$COPYRIGHT > $EMAIL"
output "$LINK"
output
output "$AJUDA > $DISCORD"
output "$AJUDA2 > $LEMBRETE"
output "$SUPORTE > $GRUPO_DISCORD"

output

Painel() {
  bash <(curl -s https://kaduprays.com/painel_1.sh)
}

Wings() {
  bash <(curl -s https://kaduprays.com/wings_1.sh)
}

Painel_07() {
  bash <(curl -s https://kaduprays.com/k_painel_07.sh)
}

Daemon_06() {
  bash <(curl -s https://kaduprays.com/k_daemon_07.sh)
}

Phpmyadmin() {

    echo "* Instalando as dependecia"
    sudo apt install unzip
    sudo apt install zip
    echo "* Dependencias instala como sucesso!"

    echo "* Craindo a pasta phpmyadmin"
    mkdir /var/www/pterodactyl/public/phpmyadmin
    echo "* Pasta criada com sucesso"

    cd /var/www/pterodactyl/public/phpmyadmin

    echo "* Instalando o phpmyadmin"
    wget https://kaduprays.com/phpmyadmin.zip

    echo "* Extraindo arquvos"
    unzip phpmyadmin.zip

    echo "* Removendo historico"
    rm phpmyadmin.zip
    clear
    clear

    echo "* Instalado com sucesso!" 
    echo "* "
    echo "* Para acessar seu banco de dados"
    echo "* Utilize panel.exemplo.com/phpmyadmin"

}

while [ "$done" == false ]; do
  options=(
    "Instalar painel 1.4.1"
    "Instalar Wings 1.4.2\n"

    "Instalar painel 0.7"
    "Instalar daemon 0.6\n"

    "Instalar phpmyadmin 5.1.1"
  )

  actions=(
    "Painel"
    "Wings"

    "Painel_07"
    "Daemon_06"

    "Phpmyadmin"
  )

  output "Qual vamos instalar?"

  for i in "${!options[@]}"; do
    output "[$i] ${options[$i]}"
  done

  echo -n "* Escolha 0-$((${#actions[@]}-1)): "
  read -r action

  [ -z "$action" ] && error "Escolha uma opção valida." && continue

  valid_input=("$(for ((i=0;i<=${#actions[@]}-1;i+=1)); do echo "${i}"; done)")
  [[ ! " ${valid_input[*]} " =~ ${action} ]] && error "Opção invalida."
  [[ " ${valid_input[*]} " =~ ${action} ]] && done=true && eval "${actions[$action]}"
done
