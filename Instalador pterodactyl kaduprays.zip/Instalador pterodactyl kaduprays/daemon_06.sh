#!/bin/bash

if [[ $EUID -ne 0 ]]; then
  echo "* This script must be executed with root privileges (sudo)." 1>&2
  exit 1
fi

SCRIPT_VERSION="v1.0"
LINHA1="Instalador do Pterodactyl 2021"
AJUDA="Precisa de suporte?"
AJUDA2="Atenção"
CRIADOR="KADUPRAYS"
EMAIL="suporte@kaduprays.com"
LINK="https://kaduprays.com/instalar.sh"
DISCORD="KaduPrays#7519"
LEMBRETE="Script não oficial do pterodactyl.io"
COPYRIGHT="Copyright (C) 2021"
MSG1="O instalador irá instalar o Docker, dependências necessárias para o daemon."
MSG2="Bem como o daemon em si. Mas ainda é necessário para criar o node"
MSG3="No painel e, em seguida, coloque o arquivo de configuração no node manualmente após"
MSG4="A instalação foi concluída. Leia mais sobre este processo na"
MSG5="documentação oficial https://pterodactyl.io/daemon/installing.html#configure-daemon"
MSG6="este script não iniciará o daemon automaticamente (instalará o serviço systemd, não o iniciará)."
MSG7="este script não habilitará a troca (para docker)."
YES_NO="(y/N)"
NO_YES="Y/n"
ABORTADO="Instalação abortada!"
AVISO="AVISO"

CURLPATH="$(command -v curl)"
if [ -z "$CURLPATH" ]; then
    echo "* curl é necessário para que este script funcione."
    echo "* instalar usando apt (Debian e derivados) ou yum/dnf (CentOS)"
    exit 1
fi

get_latest_release() {
  curl --silent "https://api.github.com/repos/$1/releases/latest" |
    grep '"tag_name":' |
    sed -E 's/.*"([^"]+)".*/\1/'
}

echo "* Retrieving release information.."
VERSION="$(get_latest_release "pterodactyl/daemon")"

echo "* Latest version is $VERSION"

DL_URL="https://github.com/pterodactyl/daemon/releases/latest/download/daemon.tar.gz"
CONFIGS_URL="https://raw.githubusercontent.com/vilhelmprytz/pterodactyl-installer/master/configs"

COLOR_RED='\033[0;31m'
COLOR_NC='\033[0m'

INSTALL_STANDALONE_SFTP_SERVER=false
INSTALL_MARIADB=false

# visual functions
function print_error {
  echo ""
  echo -e "* ${COLOR_RED}ERRO${COLOR_NC}: $1"
  echo ""
}

function print_warning {
  COLOR_YELLOW='\033[1;33m'
  COLOR_NC='\033[0m'
  echo ""
  echo -e "* ${COLOR_YELLOW}AVISO${COLOR_NC}: $1"
  echo ""
}

function print_brake {
  for ((n=0;n<$1;n++));
    do
      echo -n "#"
    done
    echo ""
}

function detect_distro {
  if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$(echo "$ID" | awk '{print tolower($0)}')
    OS_VER=$VERSION_ID
  elif type lsb_release >/dev/null 2>&1; then
    OS=$(lsb_release -si | awk '{print tolower($0)}')
    OS_VER=$(lsb_release -sr)
  elif [ -f /etc/lsb-release ]; then
    . /etc/lsb-release
    OS=$(echo "$DISTRIB_ID" | awk '{print tolower($0)}')
    OS_VER=$DISTRIB_RELEASE
  elif [ -f /etc/debian_version ]; then
    OS="debian"
    OS_VER=$(cat /etc/debian_version)
  elif [ -f /etc/SuSe-release ]; then
    OS="SuSE"
    OS_VER="?"
  elif [ -f /etc/redhat-release ]; then
    OS="Red Hat/CentOS"
    OS_VER="?"
  else
    OS=$(uname -s)
    OS_VER=$(uname -r)
  fi

  OS=$(echo "$OS" | awk '{print tolower($0)}')
  OS_VER_MAJOR=$(echo "$OS_VER" | cut -d. -f1)
}

function check_os_comp {
  MACHINE_TYPE=$(uname -m)
  if [ "${MACHINE_TYPE}" != "x86_64" ]; then
    print_warning "Arquitetura detectada $MACHINE_TYPE"
    print_warning "Usar qualquer outra arquitetura de 64 bits (x86_64) pode (e irá) causar problemas."

    echo -e -n  "* Tem certeza de que deseja continuar? (y/N):"
    read -r choice

    if [[ ! "$choice" =~ [Yy] ]]; then
      print_error "Instalação abortada!"
      exit 1
    fi
  fi

  if [ "$OS" == "ubuntu" ]; then
    if [ "$OS_VER_MAJOR" == "16" ]; then
      SUPPORTED=true
    elif [ "$OS_VER_MAJOR" == "18" ]; then
      SUPPORTED=true
    elif [ "$OS_VER_MAJOR" == "20" ]; then
      SUPPORTED=true
    else
      SUPPORTED=false
    fi
  elif [ "$OS" == "zorin" ]; then
    if [ "$OS_VER_MAJOR" == "15" ]; then
      SUPPORTED=true
    else
      SUPPORTED=false
    fi
  elif [ "$OS" == "debian" ]; then
    if [ "$OS_VER_MAJOR" == "9" ]; then
      SUPPORTED=true
    elif [ "$OS_VER_MAJOR" == "10" ]; then
      SUPPORTED=true
    else
      SUPPORTED=false
    fi
  elif [ "$OS" == "centos" ]; then
    if [ "$OS_VER_MAJOR" == "7" ]; then
      SUPPORTED=true
    elif [ "$OS_VER_MAJOR" == "8" ]; then
      SUPPORTED=true
    else
      SUPPORTED=false
    fi
  else
    SUPPORTED=false
  fi

  if [ "$SUPPORTED" == true ]; then
    echo "* $OS $OS_VER é suportada."
  else
    echo "* $OS $OS_VER não é suportada"
    print_error "OS não suportada"
    exit 1
  fi

  echo -e  "* Instalando virt-what..."
  if [ "$OS" == "debian" ] || [ "$OS" == "ubuntu" ] || [ "$OS" == "zorin" ]; then
    apt-get -y update -qq > /dev/null

    apt-get install -y virt-what -qq > /dev/null

  elif [ "$OS" == "centos" ]; then
    if [ "$OS_VER_MAJOR" == "7" ]; then
      yum -q -y update

      yum -q -y install virt-what
    elif [ "$OS_VER_MAJOR" == "8" ]; then
      dnf -y -q update

      dnf install -y -q virt-what
    fi
  else
    print_error "Invalid OS."
    exit 1
  fi

  virt_serv=$(virt-what)
  if [ "$virt_serv" != "" ]; then
    print_warning "Virtualizador: ${virt_serv//$'\n'/ } detectado."
  fi

  if [ "$virt_serv" == "openvz" ] || [ "$virt_serv" == "lxc" ] ; then
    print_warning "Tipo não compatível de virtualização detectado. Consulte seu provedor de hospedagem se o seu servidor pode executar Docker ou não. Prossiga por sua conta e risco."
    print_error "Instalação abortada!"
    exit 1
  fi

  if uname -r | grep -q "xxxx"; then
    print_error "Kernel não compatível detectado."
    exit 1
  fi
}

function apt_update {
  apt update -y
  apt upgrade -y
}

function install_dep {
  if [ "$OS" == "debian" ] || [ "$OS" == "ubuntu" ] || [ "$OS" == "zorin" ]; then
    apt_update

    apt -y install tar unzip make gcc g++ python
  elif [ "$OS" == "centos" ]; then
    if [ "$OS_VER_MAJOR" == "7" ]; then
      yum -y update

      yum -y install tar unzip make gcc gcc-c++ python
    elif [ "$OS_VER_MAJOR" == "8" ]; then
      dnf -y update

      dnf install -y tar unzip make gcc gcc-c++ python2

      alternatives --set python /usr/bin/python2
    fi
  else
    print_error "OS invalida."
    exit 1
  fi
}
function install_docker {
  echo "* Instalando o docker .."
  if [ "$OS" == "debian" ]; then
    apt-get update
    apt-get -y install \
     apt-transport-https \
     ca-certificates \
     curl \
     gnupg2 \
     software-properties-common

    curl -fsSL https://download.docker.com/linux/debian/gpg | apt-key add -

    apt-key fingerprint 0EBFCD88

    add-apt-repository \
      "deb [arch=amd64] https://download.docker.com/linux/debian \
      $(lsb_release -cs) \
      stable"

    apt-get update
    apt-get -y install docker-ce

    systemctl start docker
    systemctl enable docker

  elif [ "$OS" == "ubuntu" ] || [ "$OS" == "zorin" ]; then
    apt-get update
    apt-get -y install \
      apt-transport-https \
      ca-certificates \
      curl \
      software-properties-common

    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -

    apt-key fingerprint 0EBFCD88

    sudo add-apt-repository \
     "deb [arch=amd64] https://download.docker.com/linux/ubuntu \
     $(lsb_release -cs) \
     stable"

    apt-get update
    apt-get -y install docker-ce

    systemctl start docker
    systemctl enable docker

  elif [ "$OS" == "centos" ]; then
    if [ "$OS_VER_MAJOR" == "7" ]; then
      yum install -y yum-utils device-mapper-persistent-data lvm2

      yum-config-manager \
        --add-repo \
        https://download.docker.com/linux/centos/docker-ce.repo

      yum install -y docker-ce
    elif [ "$OS_VER_MAJOR" == "8" ]; then
      dnf install -y dnf-utils device-mapper-persistent-data lvm2

      dnf config-manager --add-repo=https://download.docker.com/linux/centos/docker-ce.repo

      dnf install -y docker-ce --nobest
    fi

    systemctl start docker
    systemctl enable docker
  fi

  echo "* O Docker agora está instalado."
}

function install_nodejs {
  if [ "$OS" == "debian" ]; then
    curl -sL https://deb.nodesource.com/setup_10.x | bash -
    apt-get install -y nodejs
  elif [ "$OS" == "ubuntu" ] || [ "$OS" == "zorin" ]; then
    curl -sL https://deb.nodesource.com/setup_10.x | sudo -E bash -
    apt -y install nodejs
  elif [ "$OS" == "centos" ]; then
    curl --silent --location https://rpm.nodesource.com/setup_10.x | sudo bash -

    if [ "$OS_VER_MAJOR" == "7" ]; then
      yum -y install nodejs
    elif [ "$OS_VER_MAJOR" == "8" ]; then
      dnf -y install nodejs
    fi
  fi
}

function ptdl_dl {
  echo "* Instalando o daemon do pterodactyl .. "
  mkdir -p /srv/daemon /srv/daemon-data
  cd /srv/daemon || exit

  curl -L "$DL_URL" | tar --strip-components=1 -xzv
  npm install --only=production --unsafe-perm

  echo "* Pronto."
}

function systemd_file {
  echo "* Instalando o serviço systemd.."
  curl -o /etc/systemd/system/wings.service $CONFIGS_URL/wings.service
  systemctl daemon-reload
  systemctl enable wings
  echo "* Serviço systemd instalado!"
}

function install_standalone_sftp_server {
  echo "* Instalando servidor SFTP autônomo.."

  INSTALL_PATH="/srv/daemon/sftp-server"

  curl -Lo $INSTALL_PATH https://github.com/pterodactyl/sftp-server/releases/download/v1.0.4/sftp-server
  chmod +x $INSTALL_PATH

  curl -o /etc/systemd/system/pterosftp.service $CONFIGS_URL/pterosftp.service

  systemctl daemon-reload
  systemctl enable pterosftp
}

function install_mariadb {
  if [ "$OS" == "ubuntu" ] || [ "$OS" == "zorin" ] || [ "$OS" == "debian" ]; then
    curl -sS https://downloads.mariadb.com/MariaDB/mariadb_repo_setup | bash
    apt update && apt install mariadb-server -y
  elif [ "$OS" == "centos" ]; then
    [ "$OS_VER_MAJOR" == "7" ] && curl -sS https://downloads.mariadb.com/MariaDB/mariadb_repo_setup | bash
    [ "$OS_VER_MAJOR" == "7" ] && yum -y install mariadb-server
    [ "$OS_VER_MAJOR" == "8" ] && dnf install -y mariadb mariadb-server
  else
    print_error "Sistema operacional sem suporte para instalações MariaDB!"
  fi
  systemctl enable mariadb
  systemctl start mariadb
}

function perform_install {
  echo "* Instalando o daemon do pterodactyl.."

  install_dep
  install_docker
  install_nodejs
  ptdl_dl
  systemd_file
  [ "$INSTALL_STANDALONE_SFTP_SERVER" == true ] && install_standalone_sftp_server
  [ "$INSTALL_MARIADB" == true ] && install_mariadb

  return 0
}

function main {
  if [ -d "/srv/daemon" ]; then
    print_warning "O script detectou que você já tem daemon Pterodactyl em seu sistema! Você não pode executar o script várias vezes, ele falhará!"
    echo -e -n "* Tem certeza de que deseja continuar? (y/N): "
    read -r CONFIRM_PROCEED
    if [[ ! "$CONFIRM_PROCEED" =~ [Yy] ]]; then
      print_error "Amém você escolhou o caminho certo, era so buraco ladrão"
      exit 1
    fi
  fi

  detect_distro

  check_os_comp

  print_brake 70
  echo "* $LINHA1"
  echo "*"
  echo "* $COPYRIGHT @ $EMAIL"
  echo "* $LINK"
  echo "*"
  echo "* $LEMBRETE"
  echo "*"
  echo "* Rodando $OS na versão $OS_VER."
  print_brake 70

  echo "* "
  echo "* $MSG1"
  echo "* $MSG2"
  echo "* $MSG3"
  echo "* $MSG4"
  echo "* $MSG5"
  echo "* "
  echo -e "* ${COLOR_RED}$AVISO ${COLOR_NC}> $MSG6"
  echo -e "* ${COLOR_RED}$AVISO ${COLOR_NC}> $MSG7"
  print_brake 42

  echo -n "* Você gostaria de instalar o servidor SFTP independente após a instalação do daemon? $YES_NO "

  read -r CONFIRM_STANDALONE_SFTP_SERVER
  [[ "$CONFIRM_STANDALONE_SFTP_SERVER" =~ [Yy] ]] && INSTALL_STANDALONE_SFTP_SERVER=true

  echo -e "* ${COLOR_RED}AVISO${COLOR_NC}: Se você instalou o painel Pterodactyl na mesma máquina, não use esta opção ou o script falhará!"
  echo -n "* Você gostaria de instalar o servidor MariaDB (MySQL) no daemon também? $YES_NO "

  read -r CONFIRM_INSTALL_MARIADB
  [[ "$CONFIRM_INSTALL_MARIADB" =~ [Yy] ]] && INSTALL_MARIADB=true

  echo -n "* Continuar com a instalação? $YES_NO "

  read -r CONFIRM
  [[ "$CONFIRM" =~ [Yy] ]] && perform_install && return

  print_error "$ABORTADO"
  exit 0
}

function goodbye {
  echo ""
  print_brake 70
  echo "* Instalação completa."
  echo ""
  echo "* Certifique-se de criar o nó dentro do painel e, em seguida, copie"
  echo "* As configuração da node e cole em nano /srv/daemon/config/core.json"
  echo "* Apos isso execute"
  echo "* systemctl start wings"
  echo "* "
  echo -e "* ${COLOR_RED}AVISO${COLOR_NC} > É recomendado habilitar a troca (para Docker, leia mais sobre isso na documentação oficial)."
  echo -e "* ${COLOR_RED}AVISO${COLOR_NC} > Este script não configura seu firewall. As portas 8080 e 2022 precisam ser abertas."
  echo -e "* ${COLOR_RED}SUPORTE${COLOR_NC} > Para suporte chame no discord $DISCORD "
  print_brake 70
  echo ""
}

# run script
main
goodbye