#!/bin/bash
set -e
if [[ $EUID -ne 0 ]]; then
  echo "* Este script deve ser executado com privilégios de root (sudo)." 1>&2
  exit 1
fi

if ! [ -x "$(command -v curl)" ]; then
  echo "* curl é necessário para que este script funcione."
  echo "* instalar usando apt (Debian e derivados) ou yum / dnf (CentOS)"
  exit 1
fi
# CONFIG DO SCRIPT #
SCRIPT_VERSION="v1.0"
LINHA1="Instalador do Pterodactyl 2021"
AJUDA="Precisa de suporte?"
AJUDA2="Atenção"
CRIADOR="KADUPRAYS"
EMAIL="suporte@kaduprays.com"
LINK="https://kaduprays.com/instalar.sh"
DISCORD="KaduPrays#7519"
LEMBRETE="Script não oficial do pterodactyl.io"
COPYRIGHT="Copyright (C) 2021"
GITHUB_SOURCE="master"
SCRIPT_RELEASE="canary"
FQDN=""
MYSQL_DB="pterodactyl"
MYSQL_USER="pterodactyl"
MYSQL_PASSWORD=""
email=""
user_email=""
user_username=""
user_firstname=""
user_lastname=""
user_password=""
ASSUME_SSL=false
CONFIGURE_LETSENCRYPT=false
PANEL_DL_URL="https://github.com/pterodactyl/panel/releases/latest/download/panel.tar.gz"
GITHUB_BASE_URL="https://kaduprays.com/$GITHUB_SOURCE"
SITE="https://kaduprays.com/"
CONFIGURE_UFW=false
CONFIGURE_FIREWALL_CMD=false
CONFIGURE_FIREWALL=false
regex="^(([A-Za-z0-9]+((\.|\-|\_|\+)?[A-Za-z0-9]?)*[A-Za-z0-9]+)|[A-Za-z0-9]+)@(([A-Za-z0-9]+)+((\.|\-|\_)?([A-Za-z0-9]+)+)*)+\.([A-Za-z]{2,})+$"
get_latest_release() {
  curl --silent "https://api.github.com/repos/$1/releases/latest" |
    grep '"tag_name":' |
    sed -E 's/.*"([^"]+)".*/\1/'                                   
}
echo "* Recuperando informações de lançamento .."
PTERODACTYL_VERSION="$(get_latest_release "pterodactyl/panel")"
array_contains_element() {
  local e match="$1"
  shift
  for e; do [[ "$e" == "$match" ]] && return 0; done
  return 1
}
valid_email() {
  [[ $1 =~ ${regex} ]]
}
print_error() {
  COLOR_RED='\033[0;31m'
  COLOR_NC='\033[0m'
  echo ""
  echo -e "* ${COLOR_RED}ERRO${COLOR_NC} > $1"
  echo ""
}
print_warning() {
  COLOR_YELLOW='\033[1;33m'
  COLOR_NC='\033[0m'
  echo ""
  echo -e "* ${COLOR_YELLOW}AVISOS${COLOR_NC}> $1"
  echo ""
}
print_brake() {
  for ((n = 0; n < $1; n++)); do
    echo -n "#"
  done
  echo ""
}
hyperlink() {
  echo -e "\e]8;;${1}\a${1}\e]8;;\a"
}
required_input() {
  local __resultvar=$1
  local result=''

  while [ -z "$result" ]; do
    echo -n "* ${2}"
    read -r result

    [ -z "$result" ] && print_error "${3}"
  done

  eval "$__resultvar="'$result'""
}

email_input() {
  local __resultvar=$1
  local result=''

  while ! valid_email "$result"; do
    echo -n "* ${2}"
    read -r result

    valid_email "$result" || print_error "${3}"
  done

  eval "$__resultvar="'$result'""
}
password_input() {
  local __resultvar=$1
  local result=''
  local default="$4"
  while [ -z "$result" ]; do
    echo -n "* ${2}"
    while IFS= read -r -s -n1 char; do
      [[ -z $char ]] && {
        printf '\n'
        break
      }
      if [[ $char == $'\x7f' ]]; then
        if [ -n "$result" ]; then
          [[ -n $result ]] && result=${result%?}
          printf '\b \b'
        fi
      else
        result+=$char
        printf '*'
      fi
    done
    [ -z "$result" ] && [ -n "$default" ] && result="$default"
    [ -z "$result" ] && print_error "${3}"
  done
  eval "$__resultvar="'$result'""
}

ask_letsencrypt() {
  if [ "$CONFIGURE_UFW" == false ] && [ "$CONFIGURE_FIREWALL_CMD" == false ]; then
    print_warning "O Let's Encrypt requer que a porta 80/443 seja aberta! Você optou por sair da configuração automática do firewall; use isso por sua própria conta e risco (se a porta 80/443 for fechada, o script falhará)!"
  fi
  print_warning "Você não pode usar o Let's Encrypt com seu nome de host como um endereço IP! Deve ser um FQDN (por exemplo, panel.exemplo.com)."
  echo -e -n "* Você deseja configurar HTTPS automaticamente usando Let's Encrypt? (Y/n): "
  read -r CONFIRM_SSL
  if [[ "$CONFIRM_SSL" =~ [Yy] ]]; then
    CONFIGURE_LETSENCRYPT=true
    ASSUME_SSL=false
  fi
}

ask_assume_ssl() {
  echo "* Let's Encrypt não será configurado automaticamente por este script (usuário optou por sair)."
  echo "* Você pode 'presumir' Let's Encrypt, o que significa que o script baixará uma configuração nginx configurada para usar um certificado Let's Encrypt, mas o script não obterá o certificado para você."
  echo "* Se você assumir SSL e não obter o certificado, sua instalação não funcionará."
  echo -n "* Assumir SSL ou não? (y/N): "
  read -r ASSUME_SSL_INPUT

  [[ "$ASSUME_SSL_INPUT" =~ [Yy] ]] && ASSUME_SSL=true
  true
}

ask_firewall() {
  case "$OS" in
  ubuntu | debian)
    echo -e -n "* Quer configurar o UFW (FireWall) automaticamente? (Y/n): "
    read -r CONFIRM_UFW

    if [[ "$CONFIRM_UFW" =~ [Yy] ]]; then
      CONFIGURE_UFW=true
      CONFIGURE_FIREWALL=true
    fi
    ;;
  centos)
    echo -e -n "* Você deseja configurar automaticamente o firewall-cmd (firewall)? (Y/n):"
    read -r CONFIRM_FIREWALL_CMD

    if [[ "$CONFIRM_FIREWALL_CMD" =~ [Yy] ]]; then
      CONFIGURE_FIREWALL_CMD=true
      CONFIGURE_FIREWALL=true
    fi
    ;;
  esac
}

detect_distro() {
  if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$(echo "$ID" | awk '{print tolower($0)}')
    OS_VER=$VERSION_ID
  elif type lsb_release >/dev/null 2>&1; then
    OS=$(lsb_release -si | awk '{print tolower($0)}')
    OS_VER=$(lsb_release -sr)
  elif [ -f /etc/lsb-release ]; then
    . /etc/lsb-release
    OS=$(echo "$DISTRIB_ID" | awk '{print tolower($0)}')
    OS_VER=$DISTRIB_RELEASE
  elif [ -f /etc/debian_version ]; then
    OS="debian"
    OS_VER=$(cat /etc/debian_version)
  elif [ -f /etc/SuSe-release ]; then
    OS="SuSE"
    OS_VER="?"
  elif [ -f /etc/redhat-release ]; then
    OS="Red Hat/CentOS"
    OS_VER="?"
  else
    OS=$(uname -s)
    OS_VER=$(uname -r)
  fi

  OS=$(echo "$OS" | awk '{print tolower($0)}')
  OS_VER_MAJOR=$(echo "$OS_VER" | cut -d. -f1)
}

check_os_comp() {
  CPU_ARCHITECTURE=$(uname -m)
  if [ "${CPU_ARCHITECTURE}" != "x86_64" ]; then
    print_warning "Arquitetura de CPU detectada $CPU_ARCHITECTURE"
    print_warning "Usar qualquer outra arquitetura diferente de 64 bits (x86_64) causará problemas."

    echo -e -n "* Tem certeza de que deseja continuar? (y/N):"
    read -r choice

    if [[ ! "$choice" =~ [Yy] ]]; then
      print_error "Instalação cancelada!"
      exit 1
    fi
  fi
  case "$OS" in
  ubuntu)
    PHP_SOCKET="/run/php/php8.0-fpm.sock"
    [ "$OS_VER_MAJOR" == "18" ] && SUPPORTED=true
    [ "$OS_VER_MAJOR" == "20" ] && SUPPORTED=true
    ;;
  debian)
    PHP_SOCKET="/run/php/php8.0-fpm.sock"
    [ "$OS_VER_MAJOR" == "9" ] && SUPPORTED=true
    [ "$OS_VER_MAJOR" == "10" ] && SUPPORTED=true
    ;;
  centos)
    PHP_SOCKET="/var/run/php-fpm/pterodactyl.sock"
    [ "$OS_VER_MAJOR" == "7" ] && SUPPORTED=true
    [ "$OS_VER_MAJOR" == "8" ] && SUPPORTED=true
    ;;
  *)
    SUPPORTED=false
    ;;
  esac

  if [ "$SUPPORTED" == true ]; then
    echo "* $OS $OS_VER is supported."
  else
    echo "* $OS $OS_VER is not supported"
    print_error "Unsupported OS"
    exit 1
  fi
}

install_composer() {
  echo "* Instalando o composer ..."
  curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer
  echo "* Instalação terminada!"
}

ptdl_dl() {
  echo "* Fazendo o downalod do painel "
  mkdir -p /var/www/pterodactyl
  cd /var/www/pterodactyl || exit

  curl -Lo panel.tar.gz "$PANEL_DL_URL"
  tar -xzvf panel.tar.gz
  chmod -R 755 storage/* bootstrap/cache/

  cp .env.example .env
  [ "$OS" == "centos" ] && export PATH=/usr/local/bin:$PATH
  COMPOSER_ALLOW_SUPERUSER=1 composer install --no-dev --optimize-autoloader

  php artisan key:generate --force
  echo "* Arquivos de painel de pterodactyl baixados e dependências do compositor instaladas!"
}

create_database() {
  if [ "$OS" == "centos" ]; then
    echo "* Instalação segura MariaDB. A seguir estão os padrões de segurança."
    echo "* Definir senha de root? [Y/n] Y"
    echo "* Remover usuários anônimos? [Y/n] Y"
    echo "* Desautorizar login de root remotamente? [Y/n] Y"
    echo "* Remover banco de dados de teste e acesso a ele? [Y/n] Y"
    echo "* Recarregar tabelas de privilégios agora? [Y/n] Y"
    echo "*"

    mysql_secure_installation

    echo "* O script deveria ter pedido a você para definir a senha de root do MySQL anteriormente (não deve ser confundida com a senha de usuário do banco de dados pterodactyl)"
    echo "* O MySQL agora solicitará que você insira a senha antes de cada comando."

    echo "* Criando o user MySQL"
    mysql -u root -p -e "CREATE USER '${MYSQL_USER}'@'127.0.0.1' IDENTIFIED BY '${MYSQL_PASSWORD}';"

    echo "* Criando o banco de dados"
    mysql -u root -p -e "CREATE DATABASE ${MYSQL_DB};"

    echo "* Garantindo os previlegios"
    mysql -u root -p -e "GRANT ALL PRIVILEGES ON ${MYSQL_DB}.* TO '${MYSQL_USER}'@'127.0.0.1' WITH GRANT OPTION;"

    echo "* Adicionando os previlegios"
    mysql -u root -p -e "FLUSH PRIVILEGES;"
  else
    echo "* Execução de consultas MySQL.."

    echo "* Criando o user MySQL"
    mysql -u root -e "CREATE USER '${MYSQL_USER}'@'127.0.0.1' IDENTIFIED BY '${MYSQL_PASSWORD}';"

    echo "* Criando o banco de dados"
    mysql -u root -e "CREATE DATABASE ${MYSQL_DB};"

    echo "* Garantindo os previlegios"
    mysql -u root -e "GRANT ALL PRIVILEGES ON ${MYSQL_DB}.* TO '${MYSQL_USER}'@'127.0.0.1' WITH GRANT OPTION;"

    echo "* Adicionando os previlegios"
    mysql -u root -e "FLUSH PRIVILEGES;"

    echo "* MySQL o Banco de Dados configurado com sucesso!"
  fi
}

configure() {
  app_url="http://$FQDN"
  [ "$ASSUME_SSL" == true ] && app_url="https://$FQDN"
  [ "$CONFIGURE_LETSENCRYPT" == true ] && app_url="https://$FQDN"

  php artisan p:environment:setup \
    --author="$email" \
    --url="$app_url" \
    --timezone="$timezone" \
    --cache="redis" \
    --session="redis" \
    --queue="redis" \
    --redis-host="localhost" \
    --redis-pass="null" \
    --redis-port="6379" \
    --settings-ui=true

  php artisan p:environment:database \
    --host="127.0.0.1" \
    --port="3306" \
    --database="$MYSQL_DB" \
    --username="$MYSQL_USER" \
    --password="$MYSQL_PASSWORD"

  php artisan migrate --seed --force

  php artisan p:user:make \
    --email="$user_email" \
    --username="$user_username" \
    --name-first="$user_firstname" \
    --name-last="$user_lastname" \
    --password="$user_password" \
    --admin=1
}

set_folder_permissions() {
  case "$OS" in
  debian | ubuntu)
    chown -R www-data:www-data ./*
    ;;
  centos)
    chown -R nginx:nginx ./*
    ;;
  esac
}

insert_cronjob() {
  echo "* Instalando cronjob.. "

  crontab -l | {
    cat
    echo "* * * * * php /var/www/pterodactyl/artisan schedule:run >> /dev/null 2>&1"
  } | crontab -

  echo "* Cronjob Instalado!"
}

install_pteroq() {
  echo "* Instalado serviço pteroq.."

  curl -o /etc/systemd/system/pteroq.service $SITE/configs/pteroq.service

  case "$OS" in
  debian | ubuntu)
    sed -i -e "s@<user>@www-data@g" /etc/systemd/system/pteroq.service
    ;;
  centos)
    sed -i -e "s@<user>@nginx@g" /etc/systemd/system/pteroq.service
    ;;
  esac

  systemctl enable pteroq.service
  systemctl start pteroq

  echo "* Instalado sem erro!"
}

apt_update() {
  apt update -q -y && apt upgrade -y
}

yum_update() {
  yum -y update
}

dnf_update() {
  dnf -y upgrade
}

enable_services_debian_based() {
  systemctl enable mariadb
  systemctl enable redis-server
  systemctl start mariadb
  systemctl start redis-server
}

enable_services_centos_based() {
  systemctl enable mariadb
  systemctl enable nginx
  systemctl enable redis
  systemctl start mariadb
  systemctl start redis
}

selinux_allow() {
  setsebool -P httpd_can_network_connect 1 || true
  setsebool -P httpd_execmem 1 || true
  setsebool -P httpd_unified 1 || true
}

ubuntu20_dep() {
  echo "* Instalando as dependencias da ubuntu 20"
  apt -y install software-properties-common curl apt-transport-https ca-certificates gnupg

  add-apt-repository universe

  LC_ALL=C.UTF-8 add-apt-repository -y ppa:ondrej/php

  apt_update

  apt -y install php8.0 php8.0-{cli,gd,mysql,pdo,mbstring,tokenizer,bcmath,xml,fpm,curl,zip} mariadb-server nginx tar unzip git redis-server redis cron

  enable_services_debian_based

  echo "* Dependencias da ubuntu instalada!"
}

ubuntu18_dep() {
  echo "* Instalando as dependencias da Ubuntu 18.."
  apt -y install software-properties-common curl apt-transport-https ca-certificates gnupg

  add-apt-repository universe

  LC_ALL=C.UTF-8 add-apt-reposit

  ory -y ppa:ondrej/php

  curl -sS https://downloads.mariadb.com/MariaDB/mariadb_repo_setup | sudo bash

  apt_update

  apt -y install php8.0 php8.0-{cli,gd,mysql,pdo,mbstring,tokenizer,bcmath,xml,fpm,curl,zip} mariadb-server nginx tar unzip git redis-server redis cron

  enable_services_debian_based

  echo "* Dependencias da ubuntu instalada!"
}

debian_stretch_dep() {
  echo "* Instalando as dependencias da Debian 8/9.."

  apt -y install dirmngr

  apt install ca-certificates apt-transport-https lsb-release -y
  wget -O /etc/apt/trusted.gpg.d/php.gpg https://packages.sury.org/php/apt.gpg

  echo "deb https://packages.sury.org/php/ $(lsb_release -sc) main" | tee /etc/apt/sources.list.d/php.list

  curl -sS https://downloads.mariadb.com/MariaDB/mariadb_repo_setup | bash

  apt_update

  apt -y install php8.0 php8.0-{cli,gd,mysql,pdo,mbstring,tokenizer,bcmath,xml,fpm,curl,zip} mariadb-server nginx curl tar unzip git redis-server cron

  enable_services_debian_based

  echo "* Dependencias da debian instalada!"
}

debian_dep() {
  echo "* Instalando as dependencias da Debian 10.."
  apt -y install dirmngr

  apt install ca-certificates apt-transport-https lsb-release -y
  wget -O /etc/apt/trusted.gpg.d/php.gpg https://packages.sury.org/php/apt.gpg
  echo "deb https://packages.sury.org/php/ $(lsb_release -sc) main" | tee /etc/apt/sources.list.d/php.list

  apt_update

  apt -y install php8.0 php8.0-{cli,gd,mysql,pdo,mbstring,tokenizer,bcmath,xml,fpm,curl,zip} mariadb-server nginx curl tar unzip git redis-server cron

  enable_services_debian_based

  echo "* Dependencias da debian instalada!"
}

centos7_dep() {
  echo "* Instalando as dependencias do CentOS 7.."

  yum install -y policycoreutils policycoreutils-python selinux-policy selinux-policy-targeted libselinux-utils setroubleshoot-server setools setools-console mcstrans

  yum install -y epel-release http://rpms.remirepo.net/enterprise/remi-release-7.rpm
  yum install -y yum-utils
  yum-config-manager -y --disable remi-php54
  yum-config-manager -y --enable remi-php80
  yum_update

  curl -sS https://downloads.mariadb.com/MariaDB/mariadb_repo_setup | sudo bash

  yum -y install php php-common php-tokenizer php-curl php-fpm php-cli php-json php-mysqlnd php-mcrypt php-gd php-mbstring php-pdo php-zip php-bcmath php-dom php-opcache mariadb-server nginx curl tar zip unzip git redis

  enable_services_centos_based

  selinux_allow

  echo "* Dependencias do CenterOS instalados!"
}

centos8_dep() {
  echo "* Instalando as dependencias do CentOS 8.."

  dnf install -y policycoreutils selinux-policy selinux-policy-targeted setroubleshoot-server setools setools-console mcstrans

  dnf install -y epel-release http://rpms.remirepo.net/enterprise/remi-release-8.rpm
  dnf module enable -y php:remi-8.0
  dnf_update

  dnf install -y php php-common php-fpm php-cli php-json php-mysqlnd php-gd php-mbstring php-pdo php-zip php-bcmath php-dom php-opcache

  dnf install -y mariadb mariadb-server

  dnf install -y nginx curl tar zip unzip git redis

  enable_services_centos_based

  selinux_allow

  echo "* Dependencias do CenterOS instalados!"
}


centos_php() {
  curl -o /etc/php-fpm.d/www-pterodactyl.conf $LINK/configs/www-pterodactyl.conf

  systemctl enable php-fpm
  systemctl start php-fpm
}

firewall_ufw() {
  apt install -y ufw

  echo -e "\n* Habilitando Firewall"
  echo "* Abrindo as portas 22 > 80 > 443 (SSH-HTTP-HTTPS)"

  ufw allow ssh >/dev/null
  ufw allow http >/dev/null
  ufw allow https >/dev/null

  ufw --force enable
  ufw --force reload
  ufw status numbered | sed '/v6/d'
}

firewall_firewalld() {
  echo -e "\n* Habilitando o Firewall (firewalld)"
  echo "* Abrindo as portas 22 > 80 > 443 (SSH-HTTP-HTTPS)"

  [ "$OS_VER_MAJOR" == "7" ] && yum -y -q install firewalld >/dev/null
  [ "$OS_VER_MAJOR" == "8" ] && dnf -y -q install firewalld >/dev/null

  systemctl --now enable firewalld >/dev/null

  firewall-cmd --add-service=http --permanent -q
  firewall-cmd --add-service=https --permanent -q
  firewall-cmd --add-service=ssh --permanent -q
  firewall-cmd --reload -q

  echo "* Firewall-cmd configurado!"
  print_brake 70
}

letsencrypt() {
  FAILED=false

  case "$OS" in
  debian | ubuntu)
    apt-get -y install certbot python3-certbot-nginx
    ;;
  centos)
    [ "$OS_VER_MAJOR" == "7" ] && yum -y -q install certbot python-certbot-nginx
    [ "$OS_VER_MAJOR" == "8" ] && dnf -y -q install certbot python3-certbot-nginx
    ;;
  esac

  certbot --nginx --redirect --no-eff-email --email "$email" -d "$FQDN" || FAILED=true

  if [ ! -d "/etc/letsencrypt/live/$FQDN/" ] || [ "$FAILED" == true ]; then
    print_warning "O processo de obtenção de um certificado Let's Encrypt falhou!"
    echo -n "* Ainda assume SSL? (y/N): "
    read -r CONFIGURE_SSL

    if [[ "$CONFIGURE_SSL" =~ [Yy] ]]; then
      ASSUME_SSL=true
      CONFIGURE_LETSENCRYPT=false
      configure_nginx
    else
      ASSUME_SSL=false
      CONFIGURE_LETSENCRYPT=false
    fi
  fi
}

configure_nginx() {
  echo "* Configurando o nginx .."

  if [ $ASSUME_SSL == true ] && [ $CONFIGURE_LETSENCRYPT == false ]; then
    DL_FILE="nginx_ssl.conf"
  else
    DL_FILE="nginx.conf"
  fi

  if [ "$OS" == "centos" ]; then
    rm -rf /etc/nginx/conf.d/default

    curl -o /etc/nginx/conf.d/pterodactyl.conf $LINK/configs/$DL_FILE

    sed -i -e "s@<domain>@${FQDN}@g" /etc/nginx/conf.d/pterodactyl.conf

    sed -i -e "s@<php_socket>@${PHP_SOCKET}@g" /etc/nginx/conf.d/pterodactyl.conf
  else
    rm -rf /etc/nginx/sites-enabled/default

    curl -o /etc/nginx/sites-available/pterodactyl.conf $LINK/configs/$DL_FILE

    sed -i -e "s@<domain>@${FQDN}@g" /etc/nginx/sites-available/pterodactyl.conf

    sed -i -e "s@<php_socket>@${PHP_SOCKET}@g" /etc/nginx/sites-available/pterodactyl.conf

    [ "$OS" == "debian" ] && [ "$OS_VER_MAJOR" == "9" ] && sed -i 's/ TLSv1.3//' /etc/nginx/sites-available/pterodactyl.conf

    ln -sf /etc/nginx/sites-available/pterodactyl.conf /etc/nginx/sites-enabled/pterodactyl.conf
  fi

  if [ "$ASSUME_SSL" == false ] && [ "$CONFIGURE_LETSENCRYPT" == false ]; then
    systemctl restart nginx
  fi

  echo "* Nginx configurado!"
}

perform_install() {
  echo "* Iniciando a instalação.. isso pode demorar um pouco!"

  case "$OS" in
  debian | ubuntu)
    apt_update

    [ "$CONFIGURE_UFW" == true ] && firewall_ufw

    if [ "$OS" == "ubuntu" ]; then
      [ "$OS_VER_MAJOR" == "20" ] && ubuntu20_dep
      [ "$OS_VER_MAJOR" == "18" ] && ubuntu18_dep
    elif [ "$OS" == "debian" ]; then
      [ "$OS_VER_MAJOR" == "9" ] && debian_stretch_dep
      [ "$OS_VER_MAJOR" == "10" ] && debian_dep
    fi
    ;;

  centos)
    [ "$OS_VER_MAJOR" == "7" ] && yum_update
    [ "$OS_VER_MAJOR" == "8" ] && dnf_update

    [ "$CONFIGURE_FIREWALL_CMD" == true ] && firewall_firewalld

    [ "$OS_VER_MAJOR" == "7" ] && centos7_dep
    [ "$OS_VER_MAJOR" == "8" ] && centos8_dep
    ;;
  esac

  [ "$OS" == "centos" ] && centos_php
  install_composer
  ptdl_dl
  create_database
  configure
  set_folder_permissions
  insert_cronjob
  install_pteroq
  configure_nginx
  [ "$CONFIGURE_LETSENCRYPT" == true ] && letsencrypt
  true
}

main() {
  if [ -d "/var/www/pterodactyl" ]; then
    print_warning "O script detectou que você já tem o painel pterodactyl em seu sistema! Você não pode executar o script várias vezes, ele falhará!"
    echo -e -n "* Tem certeza de que deseja continuar? (y/N): "
    read -r CONFIRM_PROCEED
    if [[ ! "$CONFIRM_PROCEED" =~ [Yy] ]]; then
      print_error "Amém você escolheu o caminho certo, era so buraco ladrão"
      exit 1
    fi
  fi

  detect_distro

  print_brake 70
  echo "* $LINHA1 @ $SCRIPT_RELEASE"
  echo "*"
  echo "* $COPYRIGHT > $EMAIL"
  echo "* $LINK"
  echo "*"
  echo "* $LEMBRETE"
  echo "*"
  echo "* Rodando $OS na versão $OS_VER."
  echo "* Ultima versão do pterodactyl > $PTERODACTYL_VERSION"
  print_brake 70

  check_os_comp

  print_brake 72
  echo "* Configuração do banco de dados."
  echo ""
  echo "* Estas serão as credenciais usadas para comunicação entre o MySQL"
  echo "* Banco de dados e o painel. Você não precisa criar o banco de dados"
  echo "* Antes de executar esse script, ele fará isso por você."
  echo ""

  echo -n "* Nome do banco de dados (panel): "
  read -r MYSQL_DB_INPUT

  [ -z "$MYSQL_DB_INPUT" ] && MYSQL_DB="panel" || MYSQL_DB=$MYSQL_DB_INPUT

  echo -n "* Nome de usuário (pterodactyl): "
  read -r MYSQL_USER_INPUT

  [ -z "$MYSQL_USER_INPUT" ] && MYSQL_USER="pterodactyl" || MYSQL_USER=$MYSQL_USER_INPUT

  rand_pw=$(
    tr -dc 'A-Za-z0-9!"#$%&()*+,-./:;<=>?@[\]^_`{|}~' </dev/urandom | head -c 64
    echo
  )
  password_input MYSQL_PASSWORD "Senha (precione enter para gerar uma senha aleatoria): " "A senha do MySQL não pode estar vazia" "$rand_pw"

  readarray -t valid_timezones <<<"$(curl -s $LINK/configs/valid_timezones.txt)"
  echo "* Lista de fusos horários válidos aqui $(hyperlink "https://www.php.net/manual/en/timezones.php")"

  while [ -z "$timezone" ]; do
    echo -n "* Selecione a zona que você deseja [America/New_York]: "
    read -r timezone_input

    array_contains_element "$timezone_input" "${valid_timezones[@]}" && timezone="$timezone_input"
    [ -z "$timezone_input" ] && timezone="America/New_York"
  done

  email_input email "Forneça o endereço de e-mail que será usado para configurar o Let's Encrypt e o Pterodactyl:" "Email não pode estar vazio ou inválido"

  email_input user_email "Email utilizado na conta do admin: " "Email não pode estar vazio ou inválido"
  required_input user_username "Nome de usuário na conta do admin " "Nome de usuário não pode estar vazio"
  required_input user_firstname "Primeiro nome do usuário " "O nome não pode estar vazio"
  required_input user_lastname "Sobre nome do usuário " "O nome não pode estar vazio"
  password_input user_password "Senha da conta do usuário " "A senha não pode estar vazia"

  print_brake 72

  while [ -z "$FQDN" ]; do
    echo -n "* Defina o FQDN deste painel (panel.exemplo.com): "
    read -r FQDN
    [ -z "$FQDN" ] && print_error "FQDN não reconhecida | Precisa de ajuda? > $DISCORD"
  done

  ask_firewall

  ask_letsencrypt

  [ "$CONFIGURE_LETSENCRYPT" == false ] && ask_assume_ssl

  [ "$CONFIGURE_LETSENCRYPT" == true ] || [ "$ASSUME_SSL" == true ] && bash <(curl -s $LINK/lib/verify-fqdn.sh) "$FQDN" "$OS"

  summary


  echo -e -n "\n* Configuração inicial concluída. Continuar com a instalação? (y/N): "
  read -r CONFIRM
  if [[ "$CONFIRM" =~ [Yy] ]]; then
    perform_install
  else
    print_error "Instalação abortada!"
    exit 1
  fi
}

summary() {
  print_brake 62
  echo "* Pterodactyl panel $PTERODACTYL_VERSION with nginx on $OS"
  echo "* Nome do banco de dados: $MYSQL_DB"
  echo "* Nome de usuário do banco de dados: $MYSQL_USER"
  echo "* Senha do banco de dados: (censored)"
  echo "* Zona: $timezone"
  echo "* Email: $email"
  echo "* Email do usuário: $user_email"
  echo "* Nome de usuário: $user_username"
  echo "* Primeiro nome: $user_firstname"
  echo "* Sobre nome: $user_lastname"
  echo "* Senha do usuário: (censored)"
  echo "* URL/FQDN do painel: $FQDN"
  echo "* Configurar o Firewall? $CONFIGURE_FIREWALL"
  echo "* Configurar o Let's Encrypt? $CONFIGURE_LETSENCRYPT"
  echo "* Assumir SSL? $ASSUME_SSL"
  print_brake 62
}

goodbye() {
  print_brake 62
  echo "* A instalação do painel foi concluida com sucesso!"
  echo "*"

  [ "$CONFIGURE_LETSENCRYPT" == true ] && echo "* Seu painel esta disponivel em: $(hyperlink "$app_url")"
  [ "$ASSUME_SSL" == true ] && [ "$CONFIGURE_LETSENCRYPT" == false ] && echo "* Você optou por usar SSL, mas não por meio de Let's Encrypt automatic. Seu painel não funcionará até que o SSL seja configurado."
  [ "$ASSUME_SSL" == false ] && [ "$CONFIGURE_LETSENCRYPT" == false ] && echo "* Seu painel deve estar acessível em $(hyperlink "$app_url")"

  echo "*"
  echo "* A instalação está usando nginx em $OS"
  echo "* KaduPrays agradeçe pela utilização do script ^-^"
  echo "* Ficou com duvidas? > $DISCORD"
  [ "$CONFIGURE_FIREWALL" == false ] && echo -e "* ${COLOR_RED}LEMBRETE${COLOR_NC} > Se você não configurou o firewall: 80/443 (HTTP/HTTPS) é necessário para ser aberto!"
  print_brake 62
}

main
goodbye
