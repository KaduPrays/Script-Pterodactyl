#!/bin/bash
set -e

GITHUB_SOURCE="master"
SCRIPT_RELEASE="canary"
SCRIPT_VERSION="v1.0"
LINHA1="Instalador do Pterodactyl 2021"
AJUDA="Precisa de suporte?"
AJUDA2="Atenção"
CRIADOR="KADUPRAYS"
EMAIL="suporte@kaduprays.com"
LINK="https://kaduprays.com/instalar.sh"
DISCORD="KaduPrays#7519"
LEMBRETE="Script não oficial do pterodactyl.io"
COPYRIGHT="Copyright (C) 2021"

if [[ $EUID -ne 0 ]]; then
  echo "* Este script deve ser executado com privilégios de root (sudo)." 1>&2
  exit 1
fi

if ! [ -x "$(command -v curl)" ]; then
  echo "* curl é necessário para que este script funcione."
  echo "* instalar usando apt (Debian e derivados) ou yum / dnf (CentOS)"
  exit 1
fi

WINGS_DL_URL="https://github.com/pterodactyl/wings/releases/latest/download/wings_linux_amd64"
GITHUB_BASE_URL="https://kaduprays.com/$GITHUB_SOURCE"
COLOR_RED='\033[0;31m'
COLOR_NC='\033[0m'
INSTALL_MARIADB=false
CONFIGURE_FIREWALL=false
CONFIGURE_UFW=false
CONFIGURE_FIREWALL_CMD=false
CONFIGURE_LETSENCRYPT=false
FQDN=""
EMAIL=""
regex="^(([A-Za-z0-9]+((\.|\-|\_|\+)?[A-Za-z0-9]?)*[A-Za-z0-9]+)|[A-Za-z0-9]+)@(([A-Za-z0-9]+)+((\.|\-|\_)?([A-Za-z0-9]+)+)*)+\.([A-Za-z]{2,})+$"

get_latest_release() {
  curl --silent "https://api.github.com/repos/$1/releases/latest" |
    grep '"tag_name":' |
    sed -E 's/.*"([^"]+)".*/\1/'
}

echo "* Recuperando informações de lançamento.."
WINGS_VERSION="$(get_latest_release "pterodactyl/wings")"

valid_email() {
  [[ $1 =~ ${regex} ]]
}

print_error() {
  echo ""
  echo -e "* ${COLOR_RED}ERRO${COLOR_NC} > $1"
  echo ""
}

print_warning() {
  COLOR_YELLOW='\033[1;33m'
  COLOR_NC='\033[0m'
  echo ""
  echo -e "* ${COLOR_YELLOW}ALERTA${COLOR_NC} > $1"
  echo ""
}

print_brake() {
  for ((n = 0; n < $1; n++)); do
    echo -n "#"
  done
  echo ""
}

hyperlink() {
  echo -e "\e]8;;${1}\a${1}\e]8;;\a"
}

detect_distro() {
  if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$(echo "$ID" | awk '{print tolower($0)}')
    OS_VER=$VERSION_ID
  elif type lsb_release >/dev/null 2>&1; then
    OS=$(lsb_release -si | awk '{print tolower($0)}')
    OS_VER=$(lsb_release -sr)
  elif [ -f /etc/lsb-release ]; then
    . /etc/lsb-release
    OS=$(echo "$DISTRIB_ID" | awk '{print tolower($0)}')
    OS_VER=$DISTRIB_RELEASE
  elif [ -f /etc/debian_version ]; then
    OS="debian"
    OS_VER=$(cat /etc/debian_version)
  elif [ -f /etc/SuSe-release ]; then
    OS="SuSE"
    OS_VER="?"
  elif [ -f /etc/redhat-release ]; then
    OS="Red Hat/CentOS"
    OS_VER="?"
  else
    OS=$(uname -s)
    OS_VER=$(uname -r)
  fi

  OS=$(echo "$OS" | awk '{print tolower($0)}')
  OS_VER_MAJOR=$(echo "$OS_VER" | cut -d. -f1)
}

check_os_comp() {
  SUPPORTED=false

  MACHINE_TYPE=$(uname -m)
  if [ "${MACHINE_TYPE}" != "x86_64" ]; then
    print_warning "Arquitetura detectada $MACHINE_TYPE"
    print_warning "O uso de qualquer outra arquitetura diferente de 64 bits (x86_64) causará problemas."

    echo -e -n "* Tem certeza de que deseja continuar? (y/N):"
    read -r choice

    if [[ ! "$choice" =~ [Yy] ]]; then
      print_error "Instalação abortada!"
      exit 1
    fi
  fi

  case "$OS" in
  ubuntu)
    [ "$OS_VER_MAJOR" == "18" ] && SUPPORTED=true
    [ "$OS_VER_MAJOR" == "20" ] && SUPPORTED=true
    ;;
  debian)
    [ "$OS_VER_MAJOR" == "9" ] && SUPPORTED=true
    [ "$OS_VER_MAJOR" == "10" ] && SUPPORTED=true
    ;;
  centos)
    [ "$OS_VER_MAJOR" == "7" ] && SUPPORTED=true
    [ "$OS_VER_MAJOR" == "8" ] && SUPPORTED=true
    ;;
  *)
    SUPPORTED=false
    ;;
  esac

  if [ "$SUPPORTED" == true ]; then
    echo "* $OS $OS_VER É suportada"
  else
    echo "* $OS $OS_VER É suportada"
    print_error "Sem suporte OS"
    exit 1
  fi

  echo -e "* Instalando o virt-what..."
  if [ "$OS" == "debian" ] || [ "$OS" == "ubuntu" ]; then

    export DEBIAN_FRONTEND=noninteractive

    apt-get -y update -qq
    apt-get install -y virt-what -qq

    unset DEBIAN_FRONTEND
  elif [ "$OS" == "centos" ]; then
    if [ "$OS_VER_MAJOR" == "7" ]; then
      yum -q -y update

      yum -q -y install virt-what
    elif [ "$OS_VER_MAJOR" == "8" ]; then
      dnf -y -q update

      dnf install -y -q virt-what
    fi
  else
    print_error "Invalido OS."
    exit 1
  fi

  virt_serv=$(virt-what)

  case "$virt_serv" in
  openvz | lxc)
    print_warning "Tipo não compatível de virtualização detectado. Consulte seu provedor de hospedagem se o seu servidor pode executar Docker ou não. Prossiga por sua conta e risco."
    echo -e -n "* Tem certeza de que deseja continuar? (y/N): "
    read -r CONFIRM_PROCEED
    if [[ ! "$CONFIRM_PROCEED" =~ [Yy] ]]; then
      print_error "Instalação abortada!"
      exit 1
    fi
    ;;
  *)
    [ "$virt_serv" != "" ] && print_warning "Virtaulizador: $virt_serv detectado."
    ;;
  esac

  if uname -r | grep -q "xxxx"; then
    print_error "Kernel não compatível detectado."
    exit 1
  fi
}

apt_update() {
  apt update -q -y && apt upgrade -y
}

yum_update() {
  yum -y update
}

dnf_update() {
  dnf -y upgrade
}

enable_docker() {
  systemctl start docker
  systemctl enable docker
}

install_docker() {
  echo "* Instalando o docker .."
  if [ "$OS" == "debian" ] || [ "$OS" == "ubuntu" ]; then
    apt-get -y install \
      apt-transport-https \
      ca-certificates \
      gnupg2 \
      software-properties-common

    curl -fsSL https://download.docker.com/linux/"$OS"/gpg | apt-key add -

    apt-key fingerprint 0EBFCD88

    add-apt-repository \
      "deb [arch=amd64] https://download.docker.com/linux/$OS \
    $(lsb_release -cs) \
    stable"

    apt_update
    apt-get -y install docker-ce docker-ce-cli containerd.io

    enable_docker

  elif [ "$OS" == "centos" ]; then
    if [ "$OS_VER_MAJOR" == "7" ]; then
      yum install -y yum-utils device-mapper-persistent-data lvm2

      yum-config-manager \
        --add-repo \
        https://download.docker.com/linux/centos/docker-ce.repo

      yum install -y docker-ce docker-ce-cli containerd.io
    elif [ "$OS_VER_MAJOR" == "8" ]; then
      dnf install -y dnf-utils device-mapper-persistent-data lvm2

      dnf config-manager --add-repo=https://download.docker.com/linux/centos/docker-ce.repo

      dnf install -y docker-ce docker-ce-cli containerd.io --nobest
    fi

    enable_docker
  fi

  echo "* Docker foi instalado."
}

ptdl_dl() {
  echo "* Instalando a Wings do Pterodactyl.. "

  mkdir -p /etc/pterodactyl
  curl -L -o /usr/local/bin/wings "$WINGS_DL_URL"

  chmod u+x /usr/local/bin/wings

  echo "* Pronto."
}

systemd_file() {
  echo "* Instalando serviço systemd.."
  curl -o /etc/systemd/system/wings.service $GITHUB_BASE_URL/configs/wings.service
  systemctl daemon-reload
  systemctl enable wings
  echo "* Serviço systemd instalado!"
}

install_mariadb() {
  case "$OS" in
  ubuntu | debian)
    curl -sS https://downloads.mariadb.com/MariaDB/mariadb_repo_setup | bash
    apt update && apt install mariadb-server -y
    ;;
  centos)
    [ "$OS_VER_MAJOR" == "7" ] && curl -sS https://downloads.mariadb.com/MariaDB/mariadb_repo_setup | bash
    [ "$OS_VER_MAJOR" == "7" ] && yum -y install mariadb-server
    [ "$OS_VER_MAJOR" == "8" ] && dnf install -y mariadb mariadb-server
    ;;
  esac

  systemctl enable mariadb
  systemctl start mariadb
}

ask_letsencrypt() {
  if [ "$CONFIGURE_UFW" == false ] && [ "$CONFIGURE_FIREWALL_CMD" == false ]; then
    print_warning "O Let's Encrypt requer que a porta 80/443 seja aberta! Você optou por sair da configuração automática do firewall; use isso por sua própria conta e risco (se a porta 80/443 for fechada, o script falhará)!"
  fi

  print_warning "Você não pode usar o Let's Encrypt com seu nome de host como um endereço IP! Deve ser um FQDN (por exemplo, node.exemplo.com)."

  echo -e -n "* Você deseja configurar HTTPS automaticamente usando Let's Encrypt? (y/N): "
  read -r CONFIRM_SSL

  if [[ "$CONFIRM_SSL" =~ [Yy] ]]; then
    CONFIGURE_LETSENCRYPT=true
  fi
}

firewall_ufw() {
  apt install ufw -y

  echo -e "\n* Abrindo as portas do firewall"
  echo "* Abrindo a porta 22 (SSH)"
  echo "* Abrindo a porta 8080 (Daemon Port)"
  echo "* Abrindo a porta 2022 (Daemon SFTP Port)"

  ufw allow ssh >/dev/null
  ufw allow 8080 >/dev/null
  ufw allow 2022 >/dev/null

  [ "$CONFIGURE_LETSENCRYPT" == true ] && ufw allow http >/dev/null
  [ "$CONFIGURE_LETSENCRYPT" == true ] && ufw allow https >/dev/null

  ufw --force enable
  ufw --force reload
  ufw status numbered | sed '/v6/d'
}

firewall_firewalld() {
  echo -e "\n* Ativando o Firewall (firewalld)"
  echo "* Opening port 22 (SSH)" 
  echo "* Abrindo a porta 8080 (Daemon Port)"
  echo "* Abrindo a porta 2022 (Daemon SFTP Port)"

  [ "$OS_VER_MAJOR" == "7" ] && yum -y -q install firewalld >/dev/null
  [ "$OS_VER_MAJOR" == "8" ] && dnf -y -q install firewalld >/dev/null

  systemctl --now enable firewalld >/dev/null

  firewall-cmd --add-service=ssh --permanent -q                                           
  firewall-cmd --add-port 8080/tcp --permanent -q                                         
  firewall-cmd --add-port 2022/tcp --permanent -q                                         
  [ "$CONFIGURE_LETSENCRYPT" == true ] && firewall-cmd --add-service=http --permanent -q
  [ "$CONFIGURE_LETSENCRYPT" == true ] && firewall-cmd --add-service=https --permanent -q

  firewall-cmd --permanent --zone=trusted --change-interface=pterodactyl0 -q
  firewall-cmd --zone=trusted --add-masquerade --permanent
  firewall-cmd --reload -q

  echo "* Firewall-cmd instalado!"
  print_brake 70
}

letsencrypt() {
  FAILED=false

  if [ "$OS" == "debian" ] || [ "$OS" == "ubuntu" ]; then
    apt-get install certbot -y
  elif [ "$OS" == "centos" ]; then
    [ "$OS_VER_MAJOR" == "7" ] && yum install certbot
    [ "$OS_VER_MAJOR" == "8" ] && dnf install certbot
  else
    print_error "OS não suportado."
    exit 1
  fi

  systemctl stop nginx || true

  certbot certonly --no-eff-email --email "$EMAIL" --standalone -d "$FQDN" || FAILED=true

  systemctl start nginx || true

  if [ ! -d "/etc/letsencrypt/live/$FQDN/" ] || [ "$FAILED" == true ]; then
    print_warning "The process of obtaining a Let's Encrypt certificate failed!"
  fi
}

perform_install() {
  echo "* Isntalado a wings do pterodactyl.."
  [ "$OS" == "ubuntu" ] || [ "$OS" == "debian" ] && apt_update
  [ "$OS" == "centos" ] && [ "$OS_VER_MAJOR" == "7" ] && yum_update
  [ "$OS" == "centos" ] && [ "$OS_VER_MAJOR" == "8" ] && dnf_update
  [ "$CONFIGURE_UFW" == true ] && firewall_ufw
  [ "$CONFIGURE_FIREWALL_CMD" == true ] && firewall_firewalld
  install_docker
  ptdl_dl
  systemd_file
  [ "$INSTALL_MARIADB" == true ] && install_mariadb
  [ "$CONFIGURE_LETSENCRYPT" == true ] && letsencrypt

  return 0
}

main() {
  if [ -d "/etc/pterodactyl" ]; then
    print_warning "O script detectou que você já tem a wings do pterodactyl em seu sistema! Você não pode executar o script várias vezes, ele falhará!"
    echo -e -n "* Tem certeza de que deseja continuar? (y/N): "
    read -r CONFIRM_PROCEED
    if [[ ! "$CONFIRM_PROCEED" =~ [Yy] ]]; then
      print_error "Amém você escolheu o caminho certo, era so buraco ladrão"
      exit 1
    fi
  fi

  detect_distro

  print_brake 70
  echo "* $LINHA1 @ $SCRIPT_RELEASE"
  echo "*"
  echo "* $COPYRIGHT @ $EMAIL"
  echo "* $LINK"
  echo "*"
  echo "* $LEMBRETE"
  echo "*"
  echo "* Rodando $OS na versão $OS_VER."
  echo "* Ultima versão da wings > $WINGS_VERSION"
  print_brake 70

  check_os_comp

  echo "* "
  echo "* O instalador irá instalar o Docker, dependências necessárias para o Wings"
  echo "* Bem como a própria Wings. Mas ainda é necessário criar o node no painel"
  echo "* No painel, em seguida coloque o arquivo de configuração do node manualmente após"
  echo "* A instalação termnar. Leia mais sobre este processo do node"
  echo "* Link oficial da Wings: $(hyperlink 'https://pterodactyl.io/wings/1.0/installing.html#configure')"
  echo "* "
  echo -e "* ${COLOR_RED}AVISO${COLOR_NC}: este script não iniciará o Wings automaticamente (instalará o serviço systemd, não o iniciará)."
  echo -e "* ${COLOR_RED}AVISO${COLOR_NC}: este script não habilitará a troca (para docker)."
  print_brake 42

  type mysql >/dev/null 2>&1 && ASK_MYSQL=false || ASK_MYSQL=true

  $ASK_MYSQL && echo -n "* Você gostaria de instalar o servidor MariaDB (MySQL) no daemon também? (y/N): "
  $ASK_MYSQL && read -r CONFIRM_INSTALL_MARIADB
  $ASK_MYSQL && [[ "$CONFIRM_INSTALL_MARIADB" =~ [Yy] ]] && INSTALL_MARIADB=true

  if [ "$OS" == "debian" ] || [ "$OS" == "ubuntu" ]; then
    echo -e -n "* Quer configurar o UFW (firewall) automaticamente? (y/N): "
    read -r CONFIRM_UFW

    if [[ "$CONFIRM_UFW" =~ [Yy] ]]; then
      CONFIGURE_UFW=true
      CONFIGURE_FIREWALL=true
    fi
  fi

  if [ "$OS" == "centos" ]; then
    echo -e -n "* Você deseja configurar automaticamente o firewall-cmd (firewall)? (y/N): "
    read -r CONFIRM_FIREWALL_CMD

    if [[ "$CONFIRM_FIREWALL_CMD" =~ [Yy] ]]; then
      CONFIGURE_FIREWALL_CMD=true
      CONFIGURE_FIREWALL=true
    fi
  fi

  ask_letsencrypt

  if [ "$CONFIGURE_LETSENCRYPT" == true ]; then
    while [ -z "$FQDN" ]; do
      echo -n "* Defina o FQDN a ser usado para Let's Encrypt (node.exemplo.com): "
      read -r FQDN

      ASK=false

      [ -z "$FQDN" ] && print_error "FQDN não pode estar vazio" 
      bash <(curl -s $GITHUB_BASE_URL/lib/verify-fqdn.sh) "$FQDN" "$OS" || ASK=true
      [ -d "/etc/letsencrypt/live/$FQDN/" ] && print_error "A certificate with this FQDN already exists!" && ASK=true

      [ "$ASK" == true ] && FQDN=""
      [ "$ASK" == true ] && echo -e -n "* Você ainda deseja configurar HTTPS automaticamente usando Let's Encrypt? (y/N): "
      [ "$ASK" == true ] && read -r CONFIRM_SSL

      if [[ ! "$CONFIRM_SSL" =~ [Yy] ]] && [ "$ASK" == true ]; then
        CONFIGURE_LETSENCRYPT=false
        FQDN="none"
      fi
    done
  fi

  if [ "$CONFIGURE_LETSENCRYPT" == true ]; then
    while ! valid_email "$EMAIL"; do
      echo -n "* Digite o endereço de e-mail para Let's Encrypt: "
      read -r EMAIL

      valid_email "$EMAIL" || print_error "Email não pode estar vazio ou inválido"
    done
  fi

  echo -n "* Continuar com a instalação? (y/N): "

  read -r CONFIRM
  [[ "$CONFIRM" =~ [Yy] ]] && perform_install && return

  print_error "Instalação abortada!"
  exit 0
}

function goodbye {
  echo ""
  print_brake 70
  echo "* A Instalação do Wings finalizou"
  echo "*"
  echo "* Para continuar, você precisa configurar o Wings para funcionar com o seu painel"
  echo "* Consulte o guia oficial, $(hyperlink 'https://pterodactyl.io/wings/1.0/installing.html#configure')"
  echo "* "
  echo "* Você pode copiar o arquivo de configuração do painel manualmente para /etc/pterodactyl/config.yml"
  echo "* Outra opção também e gerando o token na configuração da node"
  echo "* "
  echo "* Você pode então iniciar o Wings manualmente para verificar se está funcionando"
  echo "*"
  echo "* sudo wings"
  echo "*"
  echo "* Depois de verificar se ele está funcionando, use CTRL + C e inicie o Wings como um serviço (é executado em segundo plano)"
  echo "*"
  echo "* systemctl start wings"
  echo "*"
  echo -e "* ${COLOR_RED}AVISO${COLOR_NC}: É recomendado habilitar a troca (para Docker, leia mais sobre isso na documentação oficial)."
  [ "$CONFIGURE_FIREWALL" == false ] && echo -e "* ${COLOR_RED}AVISO${COLOR_NC}: Se você não configurou seu firewall, as portas 8080 e 2022 precisam ser abertas."
  print_brake 70
  echo ""
}

# run script
main
goodbye
