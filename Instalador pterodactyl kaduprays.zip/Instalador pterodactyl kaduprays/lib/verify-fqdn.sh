#!/bin/bash
set -e
CHECKIP_URL="https://checkip.pterodactyl-installer.se"
DNS_SERVER="8.8.8.8"

# exit with error status code if user is not root
if [[ $EUID -ne 0 ]]; then
  echo "* Este script deve ser executado com privilégios de root (sudo)." 1>&2
  exit 1
fi

# check for curl
if ! [ -x "$(command -v curl)" ]; then
  echo "* curl é necessário para que este script funcione."
  echo "* instalar usando apt (Debian e derivados) ou yum / dnf (CentOS)"
  exit 1
fi

output() {
  echo "* $1"
}

error() {
  COLOR_RED='\033[0;31m'
  COLOR_NC='\033[0m'

  echo ""
  echo -e "* ${COLOR_RED}ERRO${COLOR_NC}: $1"
  echo ""
}

fail() {
  output "O registro DNS ($dns_record) não corresponde ao IP do seu servidor. Certifique-se de que o FQDN $fqdn está apontando para o IP do seu servidor, $ip"
  output "Se você estiver usando Cloudflare, desative o proxy ou desative o Let's Ecnrypt."

  echo -n "* Prossiga mesmo assim (sua instalação será interrompida se você não souber o que está fazendo)? (y/N): "
  read -r override

  [[ ! "$override" =~ [Yy] ]] && error "FQDN ou registro DNS inválido" && exit 1
  return 0
}

dep_install() {
  [ "$os" == "centos" ] && yum install -q -y bind-utils
  [ "$os" == "debian" ] && apt-get install -y dnsutils -qq
  [ "$os" == "ubuntu" ] && apt-get install -y dnsutils -qq
  return 0
}

confirm() {
  output "Este script executará uma solicitação HTTPS para o endpoint $CHECKIP_URL"
  output "- não irá registrar ou compartilhar qualquer informação de IP com terceiros."
  output "Se desejar usar outro serviço, sinta-se à vontade para modificar o script."

  echo -e -n "* Eu concordo que esta solicitação HTTPS seja realizada (s / N): "
  read -r confirm
  [[ "$confirm" =~ [Yy] ]] || (error "User did not agree" && exit 1)
}

dns_verify() {
  output "Resolvendo DNS de $fqdn"
  ip=$(curl -4 -s $CHECKIP_URL)
  dns_record=$(dig +short @$DNS_SERVER "$fqdn")
  [ "${ip}" != "${dns_record}" ] && fail
  output "DNS verificado!"
}

main() {
  fqdn="$1"
  os="$2"
  dep_install
  confirm
  dns_verify
}

main "$1" "$2"
